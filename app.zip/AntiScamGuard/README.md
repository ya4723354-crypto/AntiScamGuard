# 防詐守門員（Android）

檢查手機裡有沒有「可能盜轉網銀」的 App。全部在手機上完成，**沒有網路權限、不上傳任何資料**。

## 會檢查什麼

針對自行安裝的 App（出廠內建的系統 App 不檢查）：

| 檢查項目 | 為什麼危險 |
|---|---|
| 不是從官方商店安裝 | 這波盜轉案的惡意程式，多半偽裝成影視 App，用連結下載 |
| 開啟了「無障礙」服務 | 可以看到並操作整個螢幕，等於遠端控制 |
| 可以讀取 / 接收簡訊 | 看得到銀行 OTP 驗證碼 |
| 可以讀取所有通知 | 通知裡也看得到驗證碼 |
| 是「裝置管理員」 | 可以阻止你把它移除 |
| 可以蓋在其他 App 上面 | 可以偽造登入畫面 |
| 被允許安裝其他 App | 可以再偷偷裝更多程式 |

**風險等級**
- **高風險**：非官方商店安裝，而且有無障礙、簡訊、通知或裝置管理員權限
- **注意**：有無障礙、簡訊或裝置管理員權限，或者非官方安裝又能蓋畫面、能裝 App
- **留意**：非官方商店安裝

另外也會檢查手機設定：螢幕鎖定、USB 偵錯、系統安全性更新、Android 版本。

每個可疑 App 都附有「查看權限」「解除安裝」「關閉無障礙」等按鈕，會直接帶你到系統設定頁。最下面有「撥打 165 / 110」緊急按鈕，按下只會開啟撥號畫面，不會自動撥出。

> 掃描是依照權限判斷，不能保證抓到所有惡意程式，也可能把正常 App 列出來（例如密碼管理器會用到無障礙）。看到不認識的才需要移除。

---

## 怎麼做出 APK（二選一）

### 方法 A：用 GitHub 自動打包（不用裝任何軟體）

1. 到 github.com 登入，右上角 **＋ → New repository**，名稱填 `AntiScamGuard`，選 **Private**，按 Create。
2. 在新的 repo 頁面點 **uploading an existing file**，把解壓縮後 `AntiScamGuard` 資料夾**裡面的所有檔案和資料夾**拖進去，按 **Commit changes**。
3. 檢查有沒有 `.github/workflows/build-apk.yml` 這個檔案。用網頁上傳時，隱藏資料夾有時候會被漏掉。
   如果被漏掉了：點 **Add file → Create new file**，檔名輸入 `.github/workflows/build-apk.yml`，把這個檔案的內容貼上去，再按 Commit。
4. 點上方的 **Actions** 分頁，等「打包 APK」出現綠色勾勾，大約 3–6 分鐘。
5. 點進去，在最下面的 **Artifacts** 下載 `AntiScamGuard-apk`，解壓縮後會得到 `app-debug.apk`。

### 方法 B：用 Android Studio

用 Android Studio 開啟 `AntiScamGuard` 資料夾，等它同步完成，再選 **Build → Build App Bundle(s) / APK(s) → Build APK(s)**。

---

## 安裝到手機

1. 把 `app-debug.apk` 傳到手機，例如用 LINE 傳給自己，或放 Google 雲端硬碟。
2. 點開安裝。系統會要求你允許「安裝不明應用程式」，先允許。
3. Play Protect 可能跳出「未知的 App」警告，因為這個 App 不是從 Play 商店來的。選「仍要安裝」。
4. **裝好之後，記得回到「設定 → 安裝不明應用程式」，把剛剛允許的那個 App 改回「不允許」。**
5. 打開「防詐守門員」就會自動掃描。之後每次切回這個 App，也會重新掃描一次。

## 技術資訊

- 語言：Java，只用 Android 內建元件（沒有第三方函式庫）
- minSdk 26（Android 8.0）、targetSdk 35
- 權限只有兩個：`QUERY_ALL_PACKAGES`（列出 App）、`REQUEST_DELETE_PACKAGES`（叫出解除安裝畫面）
- 程式碼：`app/src/main/java/tw/antiscam/guard/`
  - `Scanner.java`：掃描邏輯
  - `AppFinding.java`：風險判斷
  - `MainActivity.java`：畫面
