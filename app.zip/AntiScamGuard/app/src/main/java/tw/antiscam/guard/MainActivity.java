package tw.antiscam.guard;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int C_BG = Color.parseColor("#F3F5F9");
    private static final int C_CARD = Color.WHITE;
    private static final int C_TEXT = Color.parseColor("#1F2329");
    private static final int C_SUB = Color.parseColor("#5F6670");
    private static final int C_BLUE = Color.parseColor("#1565C0");
    private static final int C_RED = Color.parseColor("#C62828");
    private static final int C_RED_BG = Color.parseColor("#FDECEA");
    private static final int C_ORANGE = Color.parseColor("#E65100");
    private static final int C_ORANGE_BG = Color.parseColor("#FFF3E0");
    private static final int C_YELLOW = Color.parseColor("#8D6E00");
    private static final int C_YELLOW_BG = Color.parseColor("#FFF8E1");
    private static final int C_GREEN = Color.parseColor("#2E7D32");
    private static final int C_GREEN_BG = Color.parseColor("#E8F5E9");

    private LinearLayout content;
    private boolean scanning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(C_BG);
        getWindow().setNavigationBarColor(C_BG);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(C_BG);
        scroll.setFillViewport(true);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        content.setPadding(pad, pad, pad, pad);
        scroll.addView(content);

        // Android 15 起畫面會延伸到狀態列底下，這裡把內容往內縮
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets in = insets.getInsets(WindowInsets.Type.systemBars());
                top = in.top;
                bottom = in.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(0, top, 0, bottom);
            return insets;
        });

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 每次回到畫面（例如解除安裝後）都重新掃描
        startScan();
    }

    private void startScan() {
        if (scanning) return;
        scanning = true;
        content.removeAllViews();
        addHeader();
        TextView loading = text("掃描中，請稍候…", 18, C_SUB, false);
        loading.setPadding(0, dp(24), 0, dp(24));
        loading.setGravity(Gravity.CENTER);
        content.addView(loading);

        new Thread(() -> {
            Scanner.Result r;
            try {
                r = new Scanner(this).scan();
            } catch (Exception e) {
                r = new Scanner.Result();
            }
            final Scanner.Result result = r;
            runOnUiThread(() -> {
                scanning = false;
                if (!isFinishing()) render(result);
            });
        }).start();
    }

    // ---------------- 畫面 ----------------

    private void render(Scanner.Result r) {
        content.removeAllViews();
        addHeader();
        addSummary(r);

        if (!r.findings.isEmpty()) {
            addSection("需要你確認的 App");
            for (AppFinding f : r.findings) addFinding(f);
        }

        addSection("手機設定檢查");
        for (Scanner.DeviceCheck c : r.deviceChecks) addDeviceCheck(c);

        addSection("自己再檢查一次（系統設定捷徑）");
        addShortcuts();

        addSection("預防網銀被盜轉");
        addTips();

        addEmergency();

        TextView footer = text("本 App 沒有網路權限，掃描結果只留在你的手機裡，不會上傳。\n"
                + "掃描是依照權限判斷，不能保證找出所有惡意程式；有疑慮請直接問銀行或撥 165。", 13, C_SUB, false);
        footer.setPadding(dp(4), dp(20), dp(4), dp(12));
        content.addView(footer);
    }

    private void addHeader() {
        TextView title = text("防詐守門員", 28, C_TEXT, true);
        content.addView(title);
        TextView sub = text("檢查手機裡有沒有可能盜轉網銀的 App", 16, C_SUB, false);
        sub.setPadding(0, dp(4), 0, dp(14));
        content.addView(sub);
    }

    private void addSummary(Scanner.Result r) {
        int high = 0, medium = 0, low = 0;
        for (AppFinding f : r.findings) {
            if (f.level == AppFinding.LEVEL_HIGH) high++;
            else if (f.level == AppFinding.LEVEL_MEDIUM) medium++;
            else low++;
        }
        int deviceWarn = 0;
        for (Scanner.DeviceCheck c : r.deviceChecks) if (!c.ok) deviceWarn++;

        int fg, bg;
        String headline, detail;
        if (high > 0) {
            fg = C_RED; bg = C_RED_BG;
            headline = "⚠ 發現 " + high + " 個高風險 App";
            detail = "這些 App 不是從官方商店安裝，又拿到可以看螢幕或讀簡訊的權限。"
                    + "這正是網銀被盜轉案件的共同點，請馬上往下看。";
        } else if (medium > 0 || deviceWarn > 0) {
            fg = C_ORANGE; bg = C_ORANGE_BG;
            headline = "有 " + (medium + deviceWarn) + " 個項目需要確認";
            detail = "沒有發現高風險 App，但有權限或設定需要你看一下。";
        } else {
            fg = C_GREEN; bg = C_GREEN_BG;
            headline = "✓ 沒有發現可疑 App";
            detail = low > 0 ? "有 " + low + " 個自行安裝的 App 可以順便確認。" : "手機目前看起來沒問題。";
        }

        LinearLayout card = card(bg);
        card.addView(text(headline, 22, fg, true));
        TextView d = text(detail, 16, C_TEXT, false);
        d.setPadding(0, dp(6), 0, 0);
        card.addView(d);
        TextView meta = text("已檢查 " + r.scannedApps + " 個自行安裝的 App", 14, C_SUB, false);
        meta.setPadding(0, dp(8), 0, 0);
        card.addView(meta);

        Button rescan = button("重新掃描", C_BLUE, true);
        rescan.setOnClickListener(v -> startScan());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        lp.topMargin = dp(12);
        card.addView(rescan, lp);
        content.addView(card);
    }

    private void addFinding(AppFinding f) {
        int fg, bg;
        if (f.level == AppFinding.LEVEL_HIGH) { fg = C_RED; bg = C_RED_BG; }
        else if (f.level == AppFinding.LEVEL_MEDIUM) { fg = C_ORANGE; bg = C_ORANGE_BG; }
        else { fg = C_YELLOW; bg = C_YELLOW_BG; }

        LinearLayout card = card(C_CARD);

        // 標題列：圖示＋名稱＋等級
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        if (f.icon != null) {
            ImageView iv = new ImageView(this);
            iv.setImageDrawable(f.icon);
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(44), dp(44));
            ilp.rightMargin = dp(12);
            row.addView(iv, ilp);
        }
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        names.addView(text(f.label, 19, C_TEXT, true));
        names.addView(text(f.packageName, 12, C_SUB, false));
        row.addView(names, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView badge = text(f.levelText(), 14, fg, true);
        badge.setPadding(dp(10), dp(4), dp(10), dp(4));
        badge.setBackground(rounded(bg, dp(12)));
        row.addView(badge);
        card.addView(row);

        // 原因
        LinearLayout reasons = new LinearLayout(this);
        reasons.setOrientation(LinearLayout.VERTICAL);
        reasons.setPadding(0, dp(10), 0, 0);
        for (String reason : f.reasons) {
            TextView t = text("•  " + reason, 15, C_TEXT, false);
            t.setPadding(0, dp(2), 0, dp(2));
            reasons.addView(t);
        }
        card.addView(reasons);

        TextView advice = text(f.advice(), 15, fg, false);
        advice.setPadding(dp(10), dp(8), dp(10), dp(8));
        advice.setBackground(rounded(bg, dp(8)));
        LinearLayout.LayoutParams alp = matchWrap();
        alp.topMargin = dp(10);
        card.addView(advice, alp);

        // 動作按鈕
        if (f.deviceAdmin) {
            card.addView(actionButton("① 先取消「裝置管理員」", C_ORANGE,
                    () -> openSettings(Settings.ACTION_SECURITY_SETTINGS,
                            "請到「安全性 → 裝置管理員應用程式」，把「" + f.label + "」關閉")));
        }
        if (f.accessibility) {
            card.addView(actionButton("關閉它的「無障礙」權限", C_ORANGE,
                    () -> openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS,
                            "找到「" + f.label + "」並關閉")));
        }
        if (f.notificationAccess) {
            card.addView(actionButton("關閉它的「通知存取」權限", C_ORANGE,
                    () -> openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS,
                            "找到「" + f.label + "」並關閉")));
        }

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        Button info = button("查看權限", C_BLUE, false);
        info.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + f.packageName));
            safeStart(i, null);
        });
        Button uninstall = button("解除安裝", C_RED, true);
        uninstall.setOnClickListener(v -> {
            if (f.deviceAdmin) {
                Toast.makeText(this, "如果無法移除，請先取消它的「裝置管理員」", Toast.LENGTH_LONG).show();
            }
            Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + f.packageName));
            safeStart(i, null);
        });
        LinearLayout.LayoutParams b1 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        b1.rightMargin = dp(6);
        LinearLayout.LayoutParams b2 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        b2.leftMargin = dp(6);
        btnRow.addView(info, b1);
        btnRow.addView(uninstall, b2);
        LinearLayout.LayoutParams rlp = matchWrap();
        rlp.topMargin = dp(10);
        card.addView(btnRow, rlp);

        content.addView(card);
    }

    private void addDeviceCheck(Scanner.DeviceCheck c) {
        LinearLayout card = card(C_CARD);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView mark = text(c.ok ? "✓" : "!", 20, Color.WHITE, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(rounded(c.ok ? C_GREEN : C_ORANGE, dp(16)));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(32), dp(32));
        mlp.rightMargin = dp(12);
        row.addView(mark, mlp);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(c.title, 17, C_TEXT, true));
        col.addView(text(c.detail, 15, c.ok ? C_SUB : C_ORANGE, false));
        row.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(row);

        if (c.settingsAction != null) {
            card.addView(actionButton("前往設定", C_BLUE, () -> openSettings(c.settingsAction, null)));
        }
        content.addView(card);
    }

    private void addShortcuts() {
        LinearLayout card = card(C_CARD);
        TextView hint = text("就算掃描沒問題，也建議每個月點進去看一次。看到不認識的 App 就關掉。", 15, C_SUB, false);
        card.addView(hint);
        card.addView(actionButton("無障礙（最重要）", C_BLUE,
                () -> openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS,
                        "看「已安裝的應用程式 / 已下載的應用程式」，不認識的全部關掉")));
        card.addView(actionButton("安裝不明應用程式", C_BLUE,
                () -> openSettings(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        "每個 App 都應該是「不允許」")));
        card.addView(actionButton("通知存取權", C_BLUE,
                () -> openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS,
                        "只留下你認識的 App（例如手錶、車用）")));
        card.addView(actionButton("裝置管理員 / 安全性", C_BLUE,
                () -> openSettings(Settings.ACTION_SECURITY_SETTINGS,
                        "在「裝置管理員應用程式」裡，只應該有「尋找我的裝置」這類系統功能")));
        content.addView(card);
    }

    private void addTips() {
        LinearLayout card = card(C_CARD);
        String[] tips = {
                "App 只從 Google Play 下載，不要點簡訊、LINE、臉書裡的連結下載 App（尤其是免費看劇、追劇 App）。",
                "銀行、警察、客服「不會」叫你下載 App、開螢幕分享或告訴他驗證碼。",
                "請銀行關掉「非約定轉帳」，或把轉帳額度調到最低。手機就算被控制，也轉不出大額。",
                "開啟網銀的登入通知和交易通知。",
                "突然收不到 OTP 簡訊、網銀說換了裝置、指紋登入被取消：馬上打銀行客服。",
                "手機要設定螢幕鎖，系統更新不要一直延後。",
        };
        for (int i = 0; i < tips.length; i++) {
            TextView t = text((i + 1) + ".  " + tips[i], 16, C_TEXT, false);
            t.setPadding(0, dp(5), 0, dp(5));
            card.addView(t);
        }
        content.addView(card);
    }

    private void addEmergency() {
        LinearLayout card = card(C_RED_BG);
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) card.getLayoutParams();
        lp.topMargin = dp(18);
        card.addView(text("發現帳戶被轉帳了？", 20, C_RED, true));
        TextView d = text("1. 立刻打銀行客服止付（號碼在金融卡背面或網銀 App 裡）\n"
                + "2. 撥 165 反詐騙專線或 110 報案\n"
                + "3. 這支手機先關掉網路（開飛航模式），不要再用它操作網銀", 16, C_TEXT, false);
        d.setPadding(0, dp(6), 0, 0);
        card.addView(d);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button b165 = button("撥打 165", C_RED, true);
        b165.setOnClickListener(v -> dial("165"));
        Button b110 = button("撥打 110", C_RED, false);
        b110.setOnClickListener(v -> dial("110"));
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, dp(52), 1f);
        l1.rightMargin = dp(6);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, dp(52), 1f);
        l2.leftMargin = dp(6);
        row.addView(b165, l1);
        row.addView(b110, l2);
        LinearLayout.LayoutParams rlp = matchWrap();
        rlp.topMargin = dp(12);
        card.addView(row, rlp);
        content.addView(card);
    }

    private void addSection(String title) {
        TextView t = text(title, 18, C_TEXT, true);
        t.setPadding(dp(4), dp(20), 0, dp(8));
        content.addView(t);
    }

    // ---------------- 動作 ----------------

    private void dial(String number) {
        // 只開啟撥號畫面，由使用者自己按下撥出
        safeStart(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number)), null);
    }

    private void openSettings(String action, String hint) {
        if (hint != null) Toast.makeText(this, hint, Toast.LENGTH_LONG).show();
        safeStart(new Intent(action), new Intent(Settings.ACTION_SETTINGS));
    }

    private void safeStart(Intent intent, Intent fallback) {
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException | SecurityException e) {
            if (fallback != null) {
                try {
                    startActivity(fallback);
                    return;
                } catch (Exception ignored) {
                }
            }
            Toast.makeText(this, "這支手機打不開這個頁面，請到「設定」裡手動找", Toast.LENGTH_LONG).show();
        }
    }

    // ---------------- 樣式工具 ----------------

    private Button actionButton(String label, int color, Runnable onClick) {
        Button b = button(label, color, false);
        b.setOnClickListener(v -> onClick.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
        return b;
    }

    private Button button(String label, int color, boolean filled) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setStateListAnimator(null);
        b.setPadding(dp(8), 0, dp(8), 0);
        GradientDrawable g = rounded(filled ? color : Color.WHITE, dp(10));
        if (!filled) g.setStroke(dp(2), color);
        b.setBackground(g);
        b.setTextColor(filled ? Color.WHITE : color);
        return b;
    }

    private LinearLayout card(int bg) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(16));
        card.setBackground(rounded(bg, dp(14)));
        card.setElevation(dp(1));
        LinearLayout.LayoutParams lp = matchWrap();
        lp.bottomMargin = dp(10);
        card.setLayoutParams(lp);
        return card;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setLineSpacing(0, 1.2f);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
