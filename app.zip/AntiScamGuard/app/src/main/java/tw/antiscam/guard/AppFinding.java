package tw.antiscam.guard;

import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.List;

/** 一個被標記為可疑的 App，以及被標記的原因。 */
public class AppFinding {

    public static final int LEVEL_LOW = 1;     // 留意
    public static final int LEVEL_MEDIUM = 2;  // 注意
    public static final int LEVEL_HIGH = 3;    // 高風險

    public String packageName;
    public String label;
    public Drawable icon;
    public String installerLabel;

    public boolean sideloaded;          // 不是從官方商店安裝
    public boolean accessibility;       // 已開啟無障礙服務
    public boolean smsAccess;           // 可讀取 / 接收簡訊
    public boolean deviceAdmin;         // 裝置管理員
    public boolean notificationAccess;  // 可讀取所有通知（OTP 也在通知裡）
    public boolean overlay;             // 可蓋在其他 App 上面
    public boolean canInstallApps;      // 可以再安裝其他 App

    public int level;
    public final List<String> reasons = new ArrayList<>();

    /** 依照權限組合判斷風險等級；回傳 false 表示不用顯示。 */
    public boolean evaluate() {
        reasons.clear();
        if (sideloaded) reasons.add("不是從官方商店安裝（" + installerLabel + "）");
        if (accessibility) reasons.add("已開啟「無障礙」：可以看到並操作你的螢幕");
        if (smsAccess) reasons.add("可以讀取簡訊：可能看到銀行驗證碼 OTP");
        if (notificationAccess) reasons.add("可以讀取所有通知：可能看到驗證碼");
        if (deviceAdmin) reasons.add("是「裝置管理員」：可能阻止你移除它");
        if (overlay) reasons.add("可以蓋在其他 App 上面：可能偽造畫面");
        if (canInstallApps) reasons.add("被允許安裝其他 App");

        boolean powerful = accessibility || smsAccess || deviceAdmin || notificationAccess;

        if (sideloaded && powerful) {
            level = LEVEL_HIGH;
        } else if (accessibility || deviceAdmin || smsAccess || (sideloaded && (overlay || canInstallApps))) {
            level = LEVEL_MEDIUM;
        } else if (sideloaded || (notificationAccess && overlay)) {
            level = LEVEL_LOW;
        } else {
            level = 0;
        }
        return level > 0;
    }

    public String levelText() {
        switch (level) {
            case LEVEL_HIGH: return "高風險";
            case LEVEL_MEDIUM: return "注意";
            default: return "留意";
        }
    }

    public String advice() {
        switch (level) {
            case LEVEL_HIGH:
                return "如果你不認識這個 App，或不記得自己裝過：先關掉它的權限，再解除安裝，然後打電話給銀行確認帳戶。";
            case LEVEL_MEDIUM:
                return "確認你認識這個 App、也知道為什麼它需要這個權限。不認識就移除。";
            default:
                return "確認是你自己安裝的。不需要就移除。";
        }
    }
}
