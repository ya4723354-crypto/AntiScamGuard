package tw.antiscam.guard;

import android.Manifest;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.AppOpsManager;
import android.app.KeyguardManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.InstallSourceInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.provider.Settings;
import android.provider.Telephony;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityManager;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** 掃描手機上的 App 權限與手機安全設定。全部在手機上完成，不連網。 */
public class Scanner {

    /** 手機整體設定的檢查結果。 */
    public static class DeviceCheck {
        public final String title;
        public final String detail;
        public final boolean ok;
        public final String settingsAction; // 點了要開的設定頁，可為 null

        DeviceCheck(String title, String detail, boolean ok, String settingsAction) {
            this.title = title;
            this.detail = detail;
            this.ok = ok;
            this.settingsAction = settingsAction;
        }
    }

    public static class Result {
        public final List<AppFinding> findings = new ArrayList<>();
        public final List<DeviceCheck> deviceChecks = new ArrayList<>();
        public int scannedApps;
    }

    /** 視為可信任的官方 App 商店。 */
    private static final Map<String, String> TRUSTED_STORES = new HashMap<>();
    static {
        TRUSTED_STORES.put("com.android.vending", "Google Play");
        TRUSTED_STORES.put("com.sec.android.app.samsungapps", "Galaxy Store");
        TRUSTED_STORES.put("com.huawei.appmarket", "華為應用市場");
        TRUSTED_STORES.put("com.xiaomi.market", "小米應用商店");
        TRUSTED_STORES.put("com.xiaomi.mipicks", "小米 GetApps");
        TRUSTED_STORES.put("com.heytap.market", "OPPO 軟體商店");
        TRUSTED_STORES.put("com.oppo.market", "OPPO 軟體商店");
        TRUSTED_STORES.put("com.bbk.appstore", "vivo 應用商店");
        TRUSTED_STORES.put("com.amazon.venezia", "Amazon Appstore");
        TRUSTED_STORES.put("com.google.android.feedback", "Google Play");
    }

    private final Context ctx;
    private final PackageManager pm;

    public Scanner(Context ctx) {
        this.ctx = ctx.getApplicationContext();
        this.pm = this.ctx.getPackageManager();
    }

    public Result scan() {
        Result result = new Result();

        Set<String> accessibilityPkgs = enabledAccessibilityPackages();
        Set<String> notificationPkgs = packagesFromComponentSetting("enabled_notification_listeners");
        Set<String> adminPkgs = activeAdminPackages();
        String defaultSms = null;
        try {
            defaultSms = Telephony.Sms.getDefaultSmsPackage(ctx);
        } catch (Exception ignored) {
        }

        List<PackageInfo> packages;
        try {
            packages = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS);
        } catch (Exception e) {
            packages = Collections.emptyList();
        }

        AppOpsManager appOps = (AppOpsManager) ctx.getSystemService(Context.APP_OPS_SERVICE);
        String self = ctx.getPackageName();

        for (PackageInfo info : packages) {
            ApplicationInfo ai = info.applicationInfo;
            if (ai == null || info.packageName.equals(self)) continue;

            // 出廠內建的系統 App 無法被一般下載的惡意程式冒充，略過以免誤報
            if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            result.scannedApps++;

            boolean hasAccessibility = accessibilityPkgs.contains(info.packageName);
            boolean isAdmin = adminPkgs.contains(info.packageName);

            AppFinding f = new AppFinding();
            f.packageName = info.packageName;

            String installer = installerOf(info.packageName);
            if (installer != null && TRUSTED_STORES.containsKey(installer)) {
                f.sideloaded = false;
                f.installerLabel = TRUSTED_STORES.get(installer);
            } else {
                f.sideloaded = true;
                f.installerLabel = installer == null ? "來源不明" : "由「" + labelOf(installer) + "」安裝";
            }

            f.accessibility = hasAccessibility;
            f.deviceAdmin = isAdmin;
            f.notificationAccess = notificationPkgs.contains(info.packageName);

            boolean isDefaultSms = info.packageName.equals(defaultSms);
            f.smsAccess = !isDefaultSms
                    && (isGranted(info, Manifest.permission.READ_SMS)
                    || isGranted(info, Manifest.permission.RECEIVE_SMS));

            f.overlay = requests(info, Manifest.permission.SYSTEM_ALERT_WINDOW)
                    && opAllowed(appOps, "android:system_alert_window", ai.uid, info.packageName, false);
            f.canInstallApps = requests(info, Manifest.permission.REQUEST_INSTALL_PACKAGES)
                    && opAllowed(appOps, "android:request_install_packages", ai.uid, info.packageName, false);

            if (f.evaluate()) {
                try {
                    f.label = pm.getApplicationLabel(ai).toString();
                } catch (Exception e) {
                    f.label = info.packageName;
                }
                try {
                    f.icon = pm.getApplicationIcon(ai);
                } catch (Exception ignored) {
                }
                result.findings.add(f);
            }
        }

        // 高風險排最前面
        Collections.sort(result.findings, (a, b) -> {
            if (a.level != b.level) return b.level - a.level;
            return a.label.compareToIgnoreCase(b.label);
        });

        result.deviceChecks.addAll(deviceChecks());
        return result;
    }

    // ---------- 手機設定檢查 ----------

    private List<DeviceCheck> deviceChecks() {
        List<DeviceCheck> list = new ArrayList<>();
        ContentResolver cr = ctx.getContentResolver();

        // 1. 螢幕鎖定
        KeyguardManager km = (KeyguardManager) ctx.getSystemService(Context.KEYGUARD_SERVICE);
        boolean secure = km != null && km.isDeviceSecure();
        list.add(new DeviceCheck(
                "螢幕鎖定",
                secure ? "已設定密碼 / 圖形 / 指紋鎖" : "沒有設定螢幕鎖，手機被拿走就能直接打開網銀",
                secure,
                secure ? null : Settings.ACTION_SECURITY_SETTINGS));

        // 2. USB 偵錯
        int adb = 0;
        try {
            adb = Settings.Global.getInt(cr, Settings.Global.ADB_ENABLED, 0);
        } catch (Exception ignored) {
        }
        list.add(new DeviceCheck(
                "USB 偵錯",
                adb == 1 ? "已開啟。不是工程師的話請關掉（開發人員選項 → USB 偵錯）" : "已關閉",
                adb != 1,
                adb == 1 ? Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS : null));

        // 3. 安全性更新
        String patch = Build.VERSION.SECURITY_PATCH;
        boolean patchOk = true;
        String patchDetail = "安全性修補程式：" + patch;
        try {
            LocalDate d = LocalDate.parse(patch);
            long months = ChronoUnit.MONTHS.between(d, LocalDate.now());
            if (months >= 6) {
                patchOk = false;
                patchDetail += "（已經 " + months + " 個月沒更新，請到「設定 → 系統更新」檢查）";
            } else {
                patchDetail += "（近期有更新）";
            }
        } catch (Exception ignored) {
        }
        list.add(new DeviceCheck("系統安全性更新", patchDetail, patchOk,
                patchOk ? null : Settings.ACTION_DEVICE_INFO_SETTINGS));

        // 4. Android 版本
        boolean versionOk = Build.VERSION.SDK_INT >= 30;
        list.add(new DeviceCheck(
                "Android 版本",
                "Android " + Build.VERSION.RELEASE
                        + (versionOk ? "" : "（版本較舊，銀行 App 的保護也比較少，建議換手機或更新）"),
                versionOk, null));

        return list;
    }

    // ---------- 工具方法 ----------

    private Set<String> enabledAccessibilityPackages() {
        Set<String> set = new HashSet<>();
        try {
            AccessibilityManager am = (AccessibilityManager) ctx.getSystemService(Context.ACCESSIBILITY_SERVICE);
            if (am != null) {
                List<AccessibilityServiceInfo> list =
                        am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
                for (AccessibilityServiceInfo i : list) {
                    if (i.getResolveInfo() != null) {
                        ServiceInfo si = i.getResolveInfo().serviceInfo;
                        if (si != null) set.add(si.packageName);
                    }
                }
            }
        } catch (Exception ignored) {
        }
        set.addAll(packagesFromComponentSetting(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES));
        return set;
    }

    /** 解析 "pkg/cls:pkg/cls" 格式的系統設定。 */
    private Set<String> packagesFromComponentSetting(String key) {
        Set<String> set = new HashSet<>();
        try {
            String value = Settings.Secure.getString(ctx.getContentResolver(), key);
            if (!TextUtils.isEmpty(value)) {
                for (String part : value.split(":")) {
                    ComponentName cn = ComponentName.unflattenFromString(part);
                    if (cn != null) set.add(cn.getPackageName());
                }
            }
        } catch (Exception ignored) {
        }
        return set;
    }

    private Set<String> activeAdminPackages() {
        Set<String> set = new HashSet<>();
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) ctx.getSystemService(Context.DEVICE_POLICY_SERVICE);
            List<ComponentName> admins = dpm == null ? null : dpm.getActiveAdmins();
            if (admins != null) {
                for (ComponentName cn : admins) set.add(cn.getPackageName());
            }
        } catch (Exception ignored) {
        }
        return set;
    }

    private String installerOf(String pkg) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                InstallSourceInfo src = pm.getInstallSourceInfo(pkg);
                String name = src.getInstallingPackageName();
                if (name == null) name = src.getInitiatingPackageName();
                return name;
            } else {
                return pm.getInstallerPackageName(pkg);
            }
        } catch (Exception e) {
            return null;
        }
    }

    private String labelOf(String pkg) {
        try {
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) {
            return pkg;
        }
    }

    private static boolean requests(PackageInfo info, String perm) {
        if (info.requestedPermissions == null) return false;
        for (String p : info.requestedPermissions) {
            if (perm.equals(p)) return true;
        }
        return false;
    }

    private static boolean isGranted(PackageInfo info, String perm) {
        if (info.requestedPermissions == null || info.requestedPermissionsFlags == null) return false;
        for (int i = 0; i < info.requestedPermissions.length; i++) {
            if (perm.equals(info.requestedPermissions[i])
                    && i < info.requestedPermissionsFlags.length
                    && (info.requestedPermissionsFlags[i] & PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0) {
                return true;
            }
        }
        return false;
    }

    @SuppressWarnings("deprecation")
    private static boolean opAllowed(AppOpsManager appOps, String op, int uid, String pkg, boolean fallback) {
        if (appOps == null) return fallback;
        try {
            int mode = appOps.checkOpNoThrow(op, uid, pkg);
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return fallback;
        }
    }
}
